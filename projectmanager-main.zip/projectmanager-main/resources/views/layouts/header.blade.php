    <header>
        <nav>
            <div class="logo">
                <h4>Product Manager</h4>
            </div>
            <ul class="nav-links">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="{{ url('/products') }}">View Products</a></li>
                <li><a href="{{ url('/products/create') }}">Add Product</a></li>
            </ul>
        </nav>
    <header>
